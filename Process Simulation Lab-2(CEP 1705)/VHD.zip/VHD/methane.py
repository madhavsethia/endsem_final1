# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 12:52:41 2014

@author: IPC
"""

Pc = 4.6e6
Tc = 190.5
acc = 0.0115