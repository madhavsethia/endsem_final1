# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 11:13:31 2014

@author: IPC
"""

Pc = 4.895e6
Tc = 562.05
acc = 0.212

