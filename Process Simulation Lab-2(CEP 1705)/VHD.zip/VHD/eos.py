# -*- coding: utf-8 -*-
"""
Created on Tue Jan 21 11:22:45 2014

@author: IPC
"""
R = 8314.0  #J/kmol/K

def getaandb(T, typeEOS, typeMolecule):
    Pc = typeMolecule.Pc
    Tc = typeMolecule.Tc
    OmegaA = typeEOS.OmegaA
    OmegaB = typeEOS.OmegaB
    acc = typeMolecule.acc
    alpha = typeEOS.alpha(T/Tc, acc)
    a = OmegaA*(R*Tc)**2/Pc
    b = OmegaB*(R*Tc)/Pc   
    return a, b, alpha

def P(T, v, typeEOS, typeMolecule):
    a, b, alpha = getaandb(T, typeEOS, typeMolecule)
    pp = R*T/(v-b) - a*alpha/(v+typeEOS.epsilon*b)/(v+typeEOS.sigma*b)
    return pp
    
    
    
    
    